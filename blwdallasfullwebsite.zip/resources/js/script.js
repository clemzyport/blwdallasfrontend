$('document').ready(function () {
    
    /* For The sticky Navigation */
    
    $('.js--section-features').waypoint(function (direction) {
        if (direction == "down") {
            $('nav').addClass('sticky');
        } else {
            $('nav').removeClass('sticky');
        }
        
    }, { offset: '90px'
    });
    
    /* Scroll On Buttons */
    
    $('#js--scroll-to-signup').click(function (){
       $('html, body').animate({scrollTop: $('#js--section-form').offset().top}, 1000)        
    });
    
//       Navigation Scroll
       
       $('a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
        || location.hostname == this.hostname) {

        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
           if (target.length) {
             $('html,body').animate({
                 scrollTop: target.offset().top
            }, 1000);
            return false;
        }
    }
});
    
    $(window).scroll(function(){
        var wScroll = $(this).scrollTop();
        var showScrollButton = 50;
        if (wScroll > showScrollButton){
            $('#top').fadeIn();
        } else {
            $('#top').fadeOut();
        }
    });
    
    // Button creation
    
    $('body').append('<a id="top" href="#"><i class="ion-arrow-up-c"></i></a>');
    
    //CSS Property of the button
    
    $('#top').css({
        
        "bottom" :    "80px",
        "right" :     "50px",
        "position" :  "fixed",
        "cursor" :    "pointer",
        "z-index" :   "1",
        "display" :   "none",
        "background-color" : "rgba(230, 126, 34, 0.9)",
        "padding" :    "10px 20px",
        "color" :    "#ffffff",
        "text-decoration" :    "none",
        "border-radius" :    "5%",
        "box-shadow" :    "1px 2px 15px #484848",
        
    });
    
    $('#top').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 1000);
        return false;
    });
    
//    Animation For First Body.
    
    $('.js--wp-1').waypoint(function(direction) {
        $('.js--wp-1').addClass('animated fadeIn');
    }, {
        offset: '33%'
    });
    
    $('#js--wp-1').waypoint(function(direction) {
        $('#js--wp-1').addClass('animated fadeIn');
    }, {
        offset: '33%'
    });
    
 //    Animation For Gallery Pictures   
    
    $('.js--wp-2').waypoint(function(direction) {
        $('.js--wp-2').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-3').waypoint(function(direction) {
        $('.js--wp-3').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-4').waypoint(function(direction) {
        $('.js--wp-4').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-5').waypoint(function(direction) {
        $('.js--wp-5').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-6').waypoint(function(direction) {
        $('.js--wp-6').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-7').waypoint(function(direction) {
        $('.js--wp-7').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-8').waypoint(function(direction) {
        $('.js--wp-8').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
    $('.js--wp-9').waypoint(function(direction) {
        $('.js--wp-9').addClass('animated rubberBand');
    }, {
        offset: '25%'
    });
    
//    Animation For Testimonies
    
    $('.js--wp-10').waypoint(function(direction) {
        $('.js--wp-10').addClass('animated shake');
    }, {
        offset: '40%'
    });
    
//    Animation For Events Pictures
    
    $('.js--wp-11').waypoint(function(direction) {
        $('.js--wp-11').addClass('animated flipInY');
    }, {
        offset: '42%'
    });
    
    $('.js--wp-12').waypoint(function(direction) {
        $('.js--wp-12').addClass('animated flipInY');
    }, {
        offset: '41%'
    });
    
    $('.js--wp-13').waypoint(function(direction) {
        $('.js--wp-13').addClass('animated flipInY');
    }, {
        offset: '40%'
    });
    
    $('.js--wp-14').waypoint(function(direction) {
        $('.js--wp-14').addClass('animated flipInY');
    }, {
        offset: '40%'
    });
    
    $('.js--wp-15').waypoint(function(direction) {
        $('.js--wp-15').addClass('animated slideInLeft');
    }, {
        offset: '100%'
    });
    
//    Mobile Navigation 
    $('.js--nav-icon').click(function() {
        var nav = $('.js--main-nav');
        var icon = $('.js--nav-icon i')
        nav.slideToggle(200);
        
        if (icon.hasClass('ion-navicon-round')) {
            icon.addClass('ion-close-round');
            icon.removeClass('ion-navicon-round');
        } else {
            icon.addClass('ion-navicon-round');
            icon.removeClass('ion-close-round');
            
        }
    });
    
    
});